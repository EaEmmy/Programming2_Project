package src;

public class Teacher extends Person implements PayRoll {

    private String speciality;
    private String degree;
    private double PhDSal = 112;
    private double MasterSal = 82;
    private double BachelorSal = 42; 
    
//constructors
    public Teacher(int newID, String newName, int newAge, String newGender, String newDegree, String newSpec, int newDepartmentNum) {
        super(newID, newName, newAge, newGender, newDepartmentNum);
        this.degree = newDegree;
        this.speciality = newSpec;
    }
    
    public Teacher() {
        this.speciality = null;
        this.degree = null;
    }

    public Teacher(String newSpec, String newDegree) {
        this.speciality = newSpec;
        this.degree = newDegree;
    }

//getters
    public String getSpeciality() {
        return speciality;
    }

    public String getDegree() {
        return degree;
    }

//setters
    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

//display teacher
    public void display(){
        System.out.println("ID: " + this.id + "\nName: " + this.name + "\nAge: " + this.age+ "\nGender: " + this.gender + "\nSpeciality: " + this.speciality + "\nDegree: " + this.degree);
        System.out.println("");
    } 
         
    @Override
    public double computePayRoll(){
        if (input = PhDSal){
          return  (36 * PhDSal * 2) * 0.76;
        }else if(input = MasterSal){
          return  (36 * MasterSal * 2) * 0.76;
        }else
        return  (36 * BachelorSal * 2) * 0.76;
    }  
}
