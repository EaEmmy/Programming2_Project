package src;

import java.util.ArrayList;

public class Department {

    private int id;
    private String descrip;
    private Teacher dean;

    public ArrayList<Department> depList = new ArrayList<>();
    public ArrayList<Teacher> teachList = new ArrayList<>();
    public ArrayList<Student> stuList = new ArrayList<>();
    public ArrayList<Staff> staffList = new ArrayList<>();

//constructor
    public Department() {
    }
    
    public Department(int newId, String newDescrip) {
        this.id = newId;
        this.descrip = newDescrip;
    }

    public Department(int newId, String newDescrip, Teacher dean) {
        this.id = newId;
        this.descrip = newDescrip;
        this.dean = dean;
    }
    
//getter
    public int getId() {
        return id;
    }

    public String getDescrip() {
        return descrip;
    }

    public Teacher getDean() {
        return dean;
    }

    public ArrayList<Department> getDepList() {
        return depList;
    }

    public ArrayList<Teacher> getTeachList() {
        return teachList;
    }

    public ArrayList<Student> getStuList() {
        return stuList;
    }
    
//setters
    public void setId(int id) {
        this.id = id;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }

    public void setDean(Teacher dean) {
        this.dean = dean;
    }

    public void setDepList(ArrayList<Department> depList) {
        this.depList = depList;
    }

    public void setTeachList(ArrayList<Teacher> teachList) {
        this.teachList = teachList;
    }

    public void setStuList(ArrayList<Student> stuList) {
        this.stuList = stuList;
    }
    
//Display department
    public void display() {
        System.out.println("Department ID: " + this.id + "\nDescription: " + this.descrip);
        System.out.println("");
    }
}
