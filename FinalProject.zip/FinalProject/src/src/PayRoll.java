package src;

interface PayRoll {
    double computePayRoll();
}
