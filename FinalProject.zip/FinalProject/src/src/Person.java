package src;

public abstract class Person {
    public int id;
    public String name;
    public int age;
    public String gender;
    public int departmentNum;

//constructors    
    public Person(){
    this.id = 0;
    this.name = null;
    this.age =0;
    this.gender=null;
    }
    
    public Person(int newID, String newName, int newAge, String newGender, int newDepartmentNum){
        this.id= newID;
        this.name = newName;
        this.age= newAge;
        this.gender= newGender;
        this.departmentNum = newDepartmentNum;
    }

//getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }
    
//setters
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getDepartmentNum() {
        return departmentNum;
    }

    public void setDepartmentNum(int departmentNum) {
        this.departmentNum = departmentNum;
    }
    
    
//display person
    public void display() {
        System.out.println("ID: " + this.id + "\nName: " + this.name + "\nAge: " + this.age + "\nGender: " + this.gender);
        System.out.println("");
    }
}

