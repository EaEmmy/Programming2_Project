package src;

public class Staff extends Person implements PayRoll{
    private String duty;
    private int workload;

    public Staff(int newID, String newName, int newAge, String newGender, String duty, int workload, int newDepartmentNum) {
        super(newID, newName, newAge, newGender, newDepartmentNum);
        this.duty = duty;
        this.workload = workload;
    }
    
    public Staff() {
        this.duty = null;
        this.workload = 0;
    }


    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    public int getWorkload() {
        return workload;
    }

    public void setWorkload(int workload) {
        this.workload = workload;
    }
    
    @Override
    public double computePayRoll(){
        return workload = (int) ((workload * 32 * 2) * 0.85);
    }
}
