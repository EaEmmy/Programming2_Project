package src;

public class Student extends Person {

    private String course;
    private int semester;

//constructors
    public Student(int newID, String newName, int newAge, String newGender, String newCourse, int newSemester, int newDepartmentNum) {
        super(newID, newName, newAge, newGender, newDepartmentNum);
        this.course = newCourse;
        this.semester = newSemester;
    }

    public Student() {
        this.course = null;
        this.semester = 0;
    }

    public Student(String newCourse, int newSemester) {
        this.course = newCourse;
        this.semester = newSemester;
    }
    
//getters
    public String getCourse() {
        return course;
    }

    public int getSemester() {
        return semester;
    }
    
//setters
    public void setCourse(String course) {
        this.course = course;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

//display teacher
    public void display(){
        System.out.println("ID: " + this.id + "\nName: " + this.name + "\nAge: " + this.age+ "\nGender: " + this.gender + "\nCourse: " + this.course + "\nSemester: " + this.semester);
        System.out.println("");
    } 

}
