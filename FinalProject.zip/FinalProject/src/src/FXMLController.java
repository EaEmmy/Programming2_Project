package src;

import javafx.event.ActionEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableListBase;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

public class FXMLController implements Initializable {

    private TextField tfId;
    private TextField tfName;
    private TextField tfAge;
    private TextField tfGender;
    private TextField tfCourse;
    private TextField tfSemester;
    private TextField tfSpeciality;
    private TextField tfDegree;
    private TextField tfDuty;
    private TextField tfWorkload;
    private TextField tfDID;
    //Student
    private TableColumn<Student, Integer> colIdS;
    private TableColumn<Student, String> colNameS;
    private TableColumn<Student, Integer> colAgeS;
    private TableColumn<Student, String> colGenderS;
    private TableColumn<Student, String> colCourseS;
    private TableColumn<Student, Integer> colSemesterS;
    private TableColumn<Student, Integer> colDIDS;
    //Teacher
    private TableColumn<Teacher, Integer> colIdT;
    private TableColumn<Teacher, String> colNameT;
    private TableColumn<Teacher, Integer> colAgeT;
    private TableColumn<Teacher, String> colGenderT;
    private TableColumn<Teacher, String> colSpecialityT;
    private TableColumn<Teacher, String> colDegreeT;
    private TableColumn<Teacher, Integer> colDIDT;
    //Staff
    private TableColumn<Staff, Integer> colIdST;
    private TableColumn<Staff, String> colNameST;
    private TableColumn<Staff, Integer> colAgeST;
    private TableColumn<Staff, String> colGenderST;
    private TableColumn<Staff, String> colDutyST;
    private TableColumn<Staff, Integer> colWorkloadST;
    private TableColumn<Staff, Integer> colDIDST;
    //Student Buttons 
    private Button btnInsertS;
    private Button btnDeleteS;
    private Button btnUpdateS;
    private Button btnSearchS;
    private Button btnLoadS;
    //Teacher Buttons
    private Button btnInsertT;
    private Button btnDeleteT;
    private Button btnUpdateT;
    private Button btnSearchT;
    private Button btnLoadT;
    //Staff Buttons
    private Button btnInsertST;
    private Button btnDeleteST;
    private Button btnUpdateST;
    private Button btnSearchST;
    private Button btnLoadST;
    // Tableviews
    private TableView<Student> tvStudent;
    private TableView<Teacher> tvTeacher;
    private TableView<Staff> tvStaff;
    //Lists
    public static ObservableList<Student> stuList = FXCollections.observableArrayList();
    public static ObservableList<Teacher> teachList = FXCollections.observableArrayList();
    public static ObservableList<Staff> staffList = FXCollections.observableArrayList();
    @FXML
    private BorderPane mainPane;

    /**
     * **********************************STUDENT*******************************************************
     */
    public void getStudent(ObservableList<Student> arrS) {
        colIdS.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNameS.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAgeS.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGenderS.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colCourseS.setCellValueFactory(new PropertyValueFactory<>("course"));
        colSemesterS.setCellValueFactory(new PropertyValueFactory<>("semester"));
        colDIDS.setCellValueFactory(new PropertyValueFactory<>("d_id"));
        tvStudent.setItems(arrS);
    }

    public void getStuList() {
        Student s = new Student(Integer.parseInt(tfId.getText()),
                tfName.getText(),
                Integer.parseInt(tfAge.getText()),
                tfGender.getText(),
                tfCourse.getText(),
                Integer.parseInt(tfSemester.getText()), 
                Integer.parseInt(tfDID.getText()));
        stuList.add(s);
    }
    boolean temp = true;

    public void saveStudent() {
        getStuList();
        getStudent(stuList);
        btnSearchS.setDisable(false);
    }

    public void removeStudent() {
        for (int i = 0; i < stuList.size(); i++) {
            if (stuList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                stuList.remove(i);
            }
        }
    }

    public void updateStudent() {
        Student s = new Student(Integer.parseInt(tfId.getText()),
                tfName.getText(),
                Integer.parseInt(tfAge.getText()),
                tfGender.getText(),
                tfCourse.getText(),
                Integer.parseInt(tfSemester.getText()), 
                Integer.parseInt(tfDID.getText()));
        for (int i = 0; i < stuList.size(); i++) {
            if (stuList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                stuList.set(i, s);
            }
        }
    }

    public void searchStudent() {
        Student ms = new Student();
        for (int i = 0; i < stuList.size(); i++) {
            if (stuList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                ms.setId(stuList.get(i).getId());
                ms.setName(stuList.get(i).getName());
                ms.setAge(stuList.get(i).getAge());
                ms.setGender(stuList.get(i).getGender());
                ms.setCourse(stuList.get(i).getCourse());
                ms.setSemester(stuList.get(i).getSemester());
                ms.setDepartmentNum(stuList.get(i).getDepartmentNum());
            }

        }
        if (ms.getId() != 0) {
            tfId.setText(Integer.toString(ms.getId()));
            tfName.setText(ms.getName());
            tfAge.setText(Integer.toString(ms.getAge()));
            tfGender.setText(ms.getGender());
            tfCourse.setText(ms.getCourse());
            tfSemester.setText(Integer.toString(ms.getSemester()));
            tfDID.setText(Integer.toString(ms.getDepartmentNum()));

        } else {
            System.out.println("Student not found!");
        }
        btnDeleteS.setDisable(false);
        btnUpdateS.setDisable(false);
    }

   /* @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }*/

    private void handleButtonActionS(ActionEvent event) {
        //Add student
        if (event.getSource() == btnInsertS) {
            saveStudent();
        }
        //Delete student
        if (event.getSource() == btnDeleteS) {
            removeStudent();
        }
        //Update student
        if (event.getSource() == btnUpdateS) {
            updateStudent();
        }
        // Search student
        if (event.getSource() == btnSearchS) {
            searchStudent();
        }
        // Load students
        if (event.getSource() == btnLoadS) {
            initializeStudents(stuList);
        }
    }

    public void initializeStudents(ObservableList<Student> arrS) {

        //filewriter method  
        colIdS.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNameS.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAgeS.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGenderS.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colCourseS.setCellValueFactory(new PropertyValueFactory<>("course"));
        colSemesterS.setCellValueFactory(new PropertyValueFactory<>("semester"));
        colDIDS.setCellValueFactory(new PropertyValueFactory<>("d_id"));
        tvStudent.setItems(arrS);
        btnDeleteS.setDisable(true);
        btnUpdateS.setDisable(true);
    }

    /**
     * ************************************TEACHER********************************************************
     */
    public void getTeacher(ObservableList<Teacher> arrT) {
        colIdT.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNameT.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAgeT.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGenderT.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colSpecialityT.setCellValueFactory(new PropertyValueFactory<>("speciality"));
        colDegreeT.setCellValueFactory(new PropertyValueFactory<>("degree"));
        colDIDT.setCellValueFactory(new PropertyValueFactory<>("d_id"));
        tvTeacher.setItems(arrT);
    }

    public void getTeachList() {
        Teacher t = new Teacher(Integer.parseInt(tfId.getText()),
                tfName.getText(),
                Integer.parseInt(tfAge.getText()),
                tfGender.getText(),
                tfSpeciality.getText(),
                tfDegree.getText(),
                Integer.parseInt(tfDID.getText()));
        teachList.add(t);
    }
    //boolean temp = true;

    public void saveTeacher() {
        getTeachList();
        getTeacher(teachList);
        btnSearchT.setDisable(false);
    }

    public void removeTeacher() {
        for (int i = 0; i < teachList.size(); i++) {
            if (teachList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                teachList.remove(i);
            }
        }
    }

    public void updateTeacher() {
        Teacher t = new Teacher(Integer.parseInt(tfId.getText()),
                tfName.getText(),
                Integer.parseInt(tfAge.getText()),
                tfGender.getText(),
                tfSpeciality.getText(),
                tfDegree.getText(),
                Integer.parseInt(tfDID.getText()));
        for (int i = 0; i < teachList.size(); i++) {
            if (teachList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                teachList.set(i, t);
            }
        }
    }

    public void searchTeacher() {
        Teacher mt = new Teacher();
        for (int i = 0; i < teachList.size(); i++) {
            if (teachList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                mt.setId(teachList.get(i).getId());
                mt.setName(teachList.get(i).getName());
                mt.setAge(teachList.get(i).getAge());
                mt.setGender(teachList.get(i).getGender());
                mt.setSpeciality(teachList.get(i).getSpeciality());
                mt.setDegree(teachList.get(i).getDegree());
                mt.setDepartmentNum(teachList.get(i).getDepartmentNum());
            }

        }
        if (mt.getId() != 0) {
            tfId.setText(Integer.toString(mt.getId()));
            tfName.setText(mt.getName());
            tfAge.setText(Integer.toString(mt.getAge()));
            tfGender.setText(mt.getGender());
            tfSpeciality.setText(mt.getSpeciality());
            tfDegree.setText(mt.getDegree());
            tfDID.setText(Integer.toString(mt.getDepartmentNum()));

        } else {
            System.out.println("Teacher not found!");
        }
        btnDeleteT.setDisable(false);
        btnUpdateT.setDisable(false);
    }

    /*@Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }*/
    private void handleButtonActionT(ActionEvent event) {
        //Add teacher
        if (event.getSource() == btnInsertT) {
            saveTeacher();
        }
        //Delete teacher
        if (event.getSource() == btnDeleteT) {
            removeTeacher();
        }
        //Update teacher
        if (event.getSource() == btnUpdateT) {
            updateTeacher();
        }
        //Search teacher
        if (event.getSource() == btnSearchT) {
            searchTeacher();
        }
        //Load teachers
        if (event.getSource() == btnLoadT) {
            initializeTeachers(teachList);
        }
    }

    public void initializeTeachers(ObservableList<Teacher> arrT) {

        //filewriter method  
        colIdT.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNameT.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAgeT.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGenderT.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colSpecialityT.setCellValueFactory(new PropertyValueFactory<>("speciality"));
        colDegreeT.setCellValueFactory(new PropertyValueFactory<>("degree"));
        colDIDT.setCellValueFactory(new PropertyValueFactory<>("d_id"));
        tvTeacher.setItems(arrT);
        btnDeleteT.setDisable(true);
        btnUpdateT.setDisable(true);
    }

    /**
     * ***********************************STAFF********************************************************
     */
    public void getStaff(ObservableList<Staff> arrST) {
        colIdST.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNameST.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAgeST.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGenderST.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colDutyST.setCellValueFactory(new PropertyValueFactory<>("duty"));
        colWorkloadST.setCellValueFactory(new PropertyValueFactory<>("workload"));
        colDIDST.setCellValueFactory(new PropertyValueFactory<>("d_id"));
        tvStaff.setItems(arrST);
    }

    public void getStaffList() {
        Staff st = new Staff(Integer.parseInt(tfId.getText()),
                tfName.getText(),
                Integer.parseInt(tfAge.getText()),
                tfGender.getText(),
                tfDuty.getText(),
                Integer.parseInt(tfWorkload.getText()),
                Integer.parseInt(tfDID.getText()));
        staffList.add(st);
    }
    //boolean temp = true;

    public void saveStaff() {
        getStaffList();
        getStaff(staffList);
        btnSearchST.setDisable(false);
    }

    public void removeStaff() {
        for (int i = 0; i < staffList.size(); i++) {
            if (staffList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                staffList.remove(i);
            }
        }
    }

    public void updateStaff() {
        Staff st = new Staff(Integer.parseInt(tfId.getText()),
                tfName.getText(),
                Integer.parseInt(tfAge.getText()),
                tfGender.getText(),
                tfDuty.getText(),
                Integer.parseInt(tfWorkload.getText()),
                Integer.parseInt(tfDID.getText()));
        for (int i = 0; i < staffList.size(); i++) {
            if (staffList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                staffList.set(i, st);
            }
        }
    }

    public void searchStaff() {
        Staff mst = new Staff();
        for (int i = 0; i < staffList.size(); i++) {
            if (staffList.get(i).getId() == Integer.parseInt(tfId.getText())) {
                mst.setId(staffList.get(i).getId());
                mst.setName(staffList.get(i).getName());
                mst.setAge(staffList.get(i).getAge());
                mst.setGender(staffList.get(i).getGender());
                mst.setDuty(staffList.get(i).getDuty());
                mst.setWorkload(staffList.get(i).getWorkload());
                mst.setDepartmentNum(staffList.get(i).getDepartmentNum());
            }

        }
        if (mst.getId() != 0) {
            tfId.setText(Integer.toString(mst.getId()));
            tfName.setText(mst.getName());
            tfAge.setText(Integer.toString(mst.getAge()));
            tfGender.setText(mst.getGender());
            tfDuty.setText(mst.getDuty());
            tfWorkload.setText(Integer.toString(mst.getWorkload()));
            tfDID.setText(Integer.toString(mst.getDepartmentNum()));

        } else {
            System.out.println("Staff not found!");
        }
        btnDeleteST.setDisable(false);
        btnUpdateST.setDisable(false);
    }

    /*@Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }*/
    private void handleButtonActionST(ActionEvent event) {
        //Add staff
        if (event.getSource() == btnInsertST) {
            saveStaff();
        }
        //Delete staff
        if (event.getSource() == btnDeleteST) {
            removeStaff();
        }
        //Update staff
        if (event.getSource() == btnUpdateST) {
            updateStaff();
        }
        //Search staff
        if (event.getSource() == btnSearchST) {
            searchStaff();
        }
        //Load staff
        if (event.getSource() == btnLoadST) {
            initializeStaff(staffList);
        }
    }

    public void initializeStaff(ObservableList<Staff> arrST) {

        //filewriter method  
        colIdST.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNameST.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAgeST.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGenderST.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colDutyST.setCellValueFactory(new PropertyValueFactory<>("duty"));
        colWorkloadST.setCellValueFactory(new PropertyValueFactory<>("workload"));
        colDIDST.setCellValueFactory(new PropertyValueFactory<>("d_id"));
        tvStaff.setItems(arrST);
        btnDeleteST.setDisable(true);
        btnUpdateST.setDisable(true);
    }
    
    /*************MultiScreens*****************/

    @FXML
    private void handleButton1Action(ActionEvent event) {
        System.out.println("Click");
        FxmlLoader object = new FxmlLoader();
        Pane view = object.getPage("FXML_Student");
        mainPane.setCenter(view);
    }

    @FXML
    private void handleButton2Action(ActionEvent event) {
        System.out.println("Click");
        FxmlLoader object = new FxmlLoader();
        Pane view = object.getPage("FXML_Teacher");
        mainPane.setCenter(view);

    }

    @FXML
    private void handleButton3Action(ActionEvent event) {
        System.out.println("Click");
        FxmlLoader object = new FxmlLoader();
        Pane view = object.getPage("FXML_Staff");
        mainPane.setCenter(view);

    }
    
     @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
